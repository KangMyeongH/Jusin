#include "MainGame.h"

#include "StartMenu.h"

MainGame::MainGame()
{
	mMenu = nullptr;
}

MainGame::~MainGame()
{
	mMenu->RenderMenu();
	delete mMenu;
}

void MainGame::Initialize()
{
	if(!mMenu)	mMenu = new StartMenu(eMenuType::Start);
	EntityManager::GetInstance().Initialize();
}

void MainGame::Update()
{
	bool bRun = true;
	while (bRun)
	{
		mMenu->RenderMenu();
		mMenu->SelectMenu();
		bRun = mMenu->SwitchMenu(&mMenu);
	}
}
