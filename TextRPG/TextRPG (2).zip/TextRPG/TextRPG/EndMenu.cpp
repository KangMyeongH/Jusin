#include "EndMenu.h"

void EndMenu::RenderMenu()
{
	Menu::RenderMenu();
}

void EndMenu::SelectMenu()
{
	
}
